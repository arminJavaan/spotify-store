// frontend/src/pages/admin/SupportTicketsAdmin.jsx

import React, { useEffect, useState } from "react";
import API from "../../api";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Clock,
  Paperclip,
  CheckCircle,
  Loader,
  XCircle,
} from "lucide-react";

export default function SupportTicketsAdmin() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [replyingId, setReplyingId] = useState(null);
  const [replyText, setReplyText] = useState("");

  const fetchTickets = async () => {
    try {
      const res = await API.get("/support/all");
      setTickets(res.data);
    } catch (err) {
      setError("خطا در دریافت تیکت‌ها");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleReply = async (ticketId) => {
    if (!replyText.trim()) return;
    setReplyingId(ticketId);
    try {
      await API.post(`/support/reply/${ticketId}`, { reply: replyText });
      setReplyText("");
      fetchTickets();
    } catch {
      alert("خطا در ارسال پاسخ");
    } finally {
      setReplyingId(null);
    }
  };

  return (
    <main className="min-h-screen px-4 py-20 font-vazir mt-10 text-gray-light">
      <motion.div
        className="max-w-6xl mx-auto bg-dark2 rounded-3xl p-8 border border-gray-700 shadow-xl"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-2xl font-bold text-primary mb-6 flex items-center gap-2">
          <MessageSquare /> مدیریت تیکت‌های پشتیبانی
        </h2>

        {loading ? (
          <p className="text-center text-gray-400 animate-pulse">
            در حال دریافت اطلاعات...
          </p>
        ) : error ? (
          <p className="text-center text-red-500">{error}</p>
        ) : tickets.length === 0 ? (
          <p className="text-center text-gray-400">تیکتی ثبت نشده است.</p>
        ) : (
          <div className="space-y-6 max-h-[75vh] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-primary scrollbar-track-dark3">
            {tickets.map((ticket) => (
              <motion.div
                key={ticket._id}
                className="bg-dark3 border border-gray-600 p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-semibold text-primary">
                    {ticket.subject}
                  </h3>
                  <span className="text-xs text-gray-400 flex items-center gap-1">
                    <Clock size={14} />
                    {new Date(ticket.createdAt).toLocaleString("fa-IR")}
                  </span>
                </div>
                <p className="text-sm text-gray-300 whitespace-pre-line mb-2">
                  {ticket.message}
                </p>
                {ticket.attachmentUrl && (
                  <a
                    href={ticket.attachmentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-400 underline flex items-center gap-1 mb-2"
                  >
                    <Paperclip size={14} />
                    مشاهده فایل ضمیمه
                  </a>
                )}

                <div className="border-t border-gray-700 mt-4 pt-3 space-y-2">
                  <p className="text-xs text-gray-400 mb-2">
                    از طرف:{" "}
                    <span className="text-sm font-semibold text-white">
                      {ticket.user?.name || "کاربر حذف‌شده"} (
                      {ticket.user?.email || "—"})
                    </span>
                  </p>

                  {ticket.reply ? (
                    <div className="bg-dark2 p-4 rounded-xl border border-green-700 text-sm text-green-300">
                      <p className="mb-1 flex items-center gap-1">
                        <CheckCircle size={16} />
                        پاسخ مدیر:
                      </p>
                      <p className="whitespace-pre-line">{ticket.reply}</p>
                    </div>
                  ) : (
                    <div className="mt-3">
                      <textarea
                        rows={3}
                        className="w-full bg-dark1 text-white border border-gray-600 rounded-xl p-3 focus:outline-none focus:border-primary"
                        placeholder="پاسخ خود را بنویسید..."
                        value={replyingId === ticket._id ? replyText : ""}
                        onChange={(e) => setReplyText(e.target.value)}
                      />
                      <button
                        onClick={() => handleReply(ticket._id)}
                        disabled={replyingId === ticket._id && !replyText.trim()}
                        className="mt-2 bg-primary text-dark1 font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition"
                      >
                        {replyingId === ticket._id ? (
                          <span className="flex items-center gap-2">
                            <Loader className="animate-spin" size={16} />
                            در حال ارسال...
                          </span>
                        ) : (
                          "ارسال پاسخ"
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </main>
  );
}
